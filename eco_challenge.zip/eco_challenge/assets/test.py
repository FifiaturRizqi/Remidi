import tensorflow as tf
import numpy as np
from PIL import Image

# Fungsi untuk memuat model TFLite
def load_tflite_model(model_path):
    interpreter = tf.lite.Interpreter(model_path=model_path)
    interpreter.allocate_tensors()
    return interpreter

# Fungsi untuk preprocess gambar (resize dan normalisasi)
def preprocess_image(image_path, target_size=(224, 224)):
    image = Image.open(image_path).convert('RGB')  # Pastikan gambar RGB
    image = image.resize(target_size)  # Resize gambar ke 224x224
    image_array = np.array(image, dtype=np.float32) / 255.0  # Normalisasi 0-1
    return np.expand_dims(image_array, axis=0)  # Tambahkan batch dimension [1, 224, 224, 3]

# Fungsi untuk inferensi
def run_inference(interpreter, input_data):
    input_details = interpreter.get_input_details()
    output_details = interpreter.get_output_details()
    
    interpreter.set_tensor(input_details[0]['index'], input_data)  # Set input
    interpreter.invoke()  # Jalankan inferensi
    output_data = interpreter.get_tensor(output_details[0]['index'])  # Ambil output
    return output_data

# Label klasifikasi
labels = [
    "battery_waste", "food_waste", "glassbrown_waste", "cardboard_waste",
    "clothes_waste", "greenglass_waste", "metal_waste", "paper_waste",
    "plastic_waste", "residual_waste", "footwear_waste", "whiteglass_waste"
]

# Path ke model dan gambar
MODEL_PATH = "model_unquant.tflite"
IMAGE_PATH = "C:/Users/deva pradana/Downloads/Compressed/archivegarbage/garbage_classification/biological/biological1.jpg"  # Ganti dengan path gambar uji

# Load model dan preprocess gambar
interpreter = load_tflite_model(MODEL_PATH)
input_data = preprocess_image(IMAGE_PATH)

# Jalankan inferensi
output = run_inference(interpreter, input_data)
output = np.squeeze(output)  # Hilangkan batch dimension

# Tampilkan hasil
max_index = np.argmax(output)
confidence = output[max_index]
print(f"Hasil Klasifikasi: {labels[max_index]}")
print(f"Tingkat Keyakinan: {confidence * 100:.2f}%")

# Print semua nilai output untuk debug
print("Output Tensor:")
for i, value in enumerate(output):
    print(f"{labels[i]}: {value:.4f}")
