class Reward {
  final String id;
  final String name;
  final String description;
  final String imageUrl;
  final int pointsRequired;
  final bool isAvailable;

  Reward({
    required this.id,
    required this.name,
    required this.description,
    required this.imageUrl,
    required this.pointsRequired,
    required this.isAvailable,
  });
}