import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import '../models/user_profile.dart';
import 'package:firebase_auth/firebase_auth.dart';

class ProfileService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseStorage _storage = FirebaseStorage.instance;

  Future<UserProfile> getUserProfile(String uid) async {
  try {
    final doc = await _firestore.collection('users').doc(uid).get();
    
    if (!doc.exists) {
      print("Document tidak ditemukan untuk uid: $uid");
      // Buat dokumen default jika tidak ditemukan
      final defaultProfile = UserProfile(
        uid: uid,
        name: 'New User',
        email: FirebaseAuth.instance.currentUser?.email ?? '',
        photoUrl: null,
        phoneNumber: null,
        address: null,
      );
      
      await _firestore.collection('users').doc(uid).set(defaultProfile.toMap());
      return defaultProfile;
    }
    
    // Tambahkan print untuk debug
    print("Data dari Firestore: ${doc.data()}");
    
    return UserProfile.fromMap(doc.data()!);
  } catch (e) {
    print("Error dalam getUserProfile: $e");
    rethrow;
  }
}

  Future<void> updateUserProfile(UserProfile profile) async {
    await _firestore.collection('users').doc(profile.uid).update(profile.toMap());
  }

  Future<String> uploadProfilePicture(String uid, File imageFile) async {
    final ref = _storage.ref().child('profile_images/$uid.jpg');
    await ref.putFile(imageFile);
    return await ref.getDownloadURL();
  }
}
