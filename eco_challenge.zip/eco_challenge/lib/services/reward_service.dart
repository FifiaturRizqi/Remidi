import 'dart:math';
import 'package:eco_challenge/models/reward.dart';

class RewardService {
  String _generateVoucherCode() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    final random = Random();
    return List.generate(8, (index) => chars[random.nextInt(chars.length)])
        .join();
  }

  Future<List<Reward>> getAvailableRewards() async {
    await Future.delayed(Duration(seconds: 1));
    return [
      Reward(
        id: '1',
        name: 'Tuperware 500ML',
        description: 'Botol',
        imageUrl: 'assets/tupperware500ml.jpg',
        pointsRequired: 2500,
        isAvailable: true,
      ),
      Reward(
        id: '2',
        name: 'Tuperware 1L',
        description: 'Botol',
        imageUrl: 'assets/tupperware1L.jpg',
        pointsRequired: 5000,
        isAvailable: true,
      ),
      Reward(
        id: '3',
        name: 'Adidas Run flay',
        description: 'Shoes',
        imageUrl: 'assets/adidas.jpg',
        pointsRequired: 10000,
        isAvailable: true,
      ),
      Reward(
        id: '4',
        name: 'Ortuside Run flash',
        description: 'Shoes',
        imageUrl: 'assets/ortuseight.jpg',
        pointsRequired: 10000,
        isAvailable: true,
      ),
    ];
  }

  Future<String> redeemReward(String rewardId) async {
    await Future.delayed(Duration(seconds: 1));
    return _generateVoucherCode();
  }
}
