import 'package:shared_preferences/shared_preferences.dart';
import 'package:firebase_auth/firebase_auth.dart';

class PointService {
  static const String _pointsKey = 'user_points';
  static const String _lastLoginKey = 'last_login_date';
  
  Future<int> getCurrentPoints() async {
    final prefs = await SharedPreferences.getInstance();
    final userId = FirebaseAuth.instance.currentUser?.uid;
    return prefs.getInt('${_pointsKey}_$userId') ?? 0;
  }

  Future<void> addPoints(int points) async {
    final prefs = await SharedPreferences.getInstance();
    final userId = FirebaseAuth.instance.currentUser?.uid;
    final currentPoints = await getCurrentPoints();
    await prefs.setInt('${_pointsKey}_$userId', currentPoints + points);
  }

  Future<void> deductPoints(int points) async {
    final prefs = await SharedPreferences.getInstance();
    final userId = FirebaseAuth.instance.currentUser?.uid;
    final currentPoints = await getCurrentPoints();
    await prefs.setInt('${_pointsKey}_$userId', currentPoints - points);
  }

  Future<bool> checkAndAddDailyLoginPoints() async {
    final prefs = await SharedPreferences.getInstance();
    final userId = FirebaseAuth.instance.currentUser?.uid;
    final lastLoginStr = prefs.getString('${_lastLoginKey}_$userId');
    
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    
    if (lastLoginStr != null) {
      final lastLogin = DateTime.parse(lastLoginStr);
      if (lastLogin.isAfter(today)) return false;
    }
    
    await addPoints(500); // Daily login points
    await prefs.setString('${_lastLoginKey}_$userId', now.toIso8601String());
    return true;
  }
}