import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart';
import 'package:eco_challenge/services/point_service.dart';

class Challenge {
  final String id;
  final String title;
  final String description;
  final int points;
  final String category;

  Challenge({
    required this.id,
    required this.title,
    required this.description,
    required this.points,
    required this.category,
  });
}

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _totalPoints = 0;
  List<Challenge> _completedChallenges = [];

  final List<Challenge> _availableChallenges = [
    Challenge(
      id: '1',
      title: 'Kurangi Plastik Sekali Pakai',
      description:
          'Gunakan tas belanja dan botol minum sendiri selama seminggu',
      points: 500,
      category: 'Plastik',
    ),
    Challenge(
      id: '2',
      title: 'Hemat Energi di Rumah',
      description: 'Matikan peralatan elektronik yang tidak digunakan',
      points: 750,
      category: 'Energi',
    ),
    Challenge(
      id: '3',
      title: 'Transportasi Ramah Lingkungan',
      description: 'Gunakan transportasi publik atau bersepeda selama 3 hari',
      points: 1000,
      category: 'Transportasi',
    ),
  ];

  @override
  void initState() {
    super.initState();
    // Simulasi pengambilan data poin dan riwayat
    _loadChallengeData();
  }

  void _loadChallengeData() {
    // Dalam implementasi nyata, gunakan penyimpanan lokal atau database
    setState(() {
      _totalPoints = 0;
      _completedChallenges = [];
    });
  }

  void _completeChallenge(Challenge challenge) {
    setState(() {
      _totalPoints += challenge.points;
      _completedChallenges.add(challenge);
    });
    final PointService _pointService = PointService();


    // Simpan ke database atau penyimpanan lokal
    _saveCompletedChallenge(challenge);
    _pointService.addPoints(challenge.points);
  }


  void _saveCompletedChallenge(Challenge challenge) {
    // Implementasi penyimpanan challenge yang diselesaikan
    // Misalnya menggunakan Firebase atau local storage
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Eco Challenge',
                          style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: Colors.green[700],
                          ),
                        ),
                        Text(
                          'Jadilah Pahlawan Lingkungan',
                          style: TextStyle(
                            color: Colors.grey[600],
                          ),
                        ),
                      ],
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 8,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.green[50],
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            Icons.stars,
                            color: Colors.green[700],
                          ),
                          const SizedBox(width: 8),
                          Text(
                            '$_totalPoints Poin',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: Colors.green[700],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 24),

                // Challenges Section
                Text(
                  'Tantangan Aktif',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.green[700],
                  ),
                ),
                const SizedBox(height: 16),
                ..._availableChallenges
                    .map((challenge) => _buildChallengeCard(challenge))
                    .toList(),

                const SizedBox(height: 24),

                // History Section
                Text(
                  'Riwayat Tantangan',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.green[700],
                  ),
                ),
                const SizedBox(height: 16),
                _buildChallengeHistory(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildChallengeCard(Challenge challenge) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              challenge.title,
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              challenge.description,
              style: TextStyle(
                color: Colors.grey[600],
              ),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '+${challenge.points} Poin',
                  style: TextStyle(
                    color: Colors.green[700],
                    fontWeight: FontWeight.bold,
                  ),
                ),
                ElevatedButton(
                  onPressed: () => _completeChallenge(challenge),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green[700],
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                  ),
                  child: const Text('Selesaikan'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildChallengeHistory() {
    if (_completedChallenges.isEmpty) {
      return Center(
        child: Text(
          'Belum ada tantangan yang diselesaikan',
          style: TextStyle(
            color: Colors.grey[600],
          ),
        ),
      );
    }

    return Column(
      children: _completedChallenges.map((challenge) {
        return Card(
          margin: const EdgeInsets.only(bottom: 16),
          child: ListTile(
            title: Text(
              challenge.title,
              style: const TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
            subtitle: Text(
              challenge.description,
              style: TextStyle(
                color: Colors.grey[600],
              ),
            ),
            trailing: Text(
              '+${challenge.points} Poin',
              style: TextStyle(
                color: Colors.green[700],
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        );
      }).toList(),
    );
  }
}
